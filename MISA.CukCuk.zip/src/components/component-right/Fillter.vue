<template>
    <div class="fillter">
        <div class="search">
            <input class="icon-search" type="text" placeholder="tìm kiếm theo Mã, Tên hoặc số điện thoại">
        </div>
            <div class="dropdow">
                <select>
                    <option>
                        Tất cả phòng ban
                    </option>
                    <option>
                        Phòng ban 1
                    </option>
                    <option>
                        Phòng ban 2
                    </option>
                </select>
            </div>
            <div class="dropdow-cv">
                <select>
                    <option>
                        Chức vụ
                    </option>
                    <option>
                        Chức vụ 1
                    </option>
                    <option>
                        Chức vụ 2
                    </option>
                </select>
            </div>
            <div class="icon">
                <button class="icon-load"></button>
            </div>
    </div>
</template>