<template>
<div class="header">
    <div class="header-left">
         <div class="custom-select">
             <select>
            <option>Nhà hàng biển đông 1</option>
            <option>Nhà hàng biển đông 2</option>
            <option>Nhà hàng biển đông 3</option>
        </select>
         </div>
    </div>

        <div class="header-right">
            <div class="account">
                <div class="icon avatar"></div>
                <div class="fullname">Nguyễn Duy Tín</div>
                <div class="icon-option option"></div>
            </div>
        </div>
    </div>
</template>
